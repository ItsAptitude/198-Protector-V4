198 Protector V4 - Modified by Aptitude

* SuperAntiDe4Dot will not work together with constant protection, apply SuperAntiDe4Dot afterwards.

This was created sometime in 2018.


Added:

- Fixed/Improved Anti-De4Dot
- Process Monitor Protection
- Force Admin Priviliges Protection
- Module Flood
- Anti Fiddler
- Anti HTTP Debugger Protection
- Random Outline Methods
- Locals-to-Field V2
- Anti DnSpy
- Hide Calls
- Headers Protection
- Hide Methods
- Anti UnsafeValue
- Anti Debug (Works DnSpy, Ollydbg, x64dbg and plugins)
- SuperAntiDe4Dot Mod by Aptitude (Will Crash Unpackers, and anti decompile on module cctor)
- Rename Module
- DebuggerDetection
- Reduce Metadata Confusion
- Constants Modified
- CTRLFlow Modified
A lot more...


Credits:

Wadu
oxd4d
yck1509
Holly-Hacker
Martin Karing
CodeofDark
BahNahNah
Charterino
Tanasittx
Eddy^CZ
KrawkRE
Dark
Rzy
Beds
